package model.entities;

public enum UserRole {
    TEACHER,
    STUDENT,
    ADMIN
}
