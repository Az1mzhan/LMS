# LMS
This repository is for the OOP project. The aim of the project is to create an LMS system on Java using main principles of OOP.
