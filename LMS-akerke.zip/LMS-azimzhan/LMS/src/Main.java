import model.Student;
import model.Subject;
import model.Teacher;
import model.UserRole;


import java.sql.*;
public class Main {

    public static void main(String[] args) {

        Teacher teacher = new Teacher(1, "Amina", "Nuradinova", "aminanuradinova@mail.com", "Aminok875", UserRole.TEACHER, "levelwtf", "PhD of IT");
        Student  student=new Student(2, "Akerke", "Orynbasarova", "orynbasarovaaaa@gmail.com", "Sharshadym362", UserRole.STUDENT, "IT-2207", "OOP");
        Subject subject=new Subject("OOP", "syllabus", 5);

        System.out.println("-----------------------------Test---------------------------------");
        System.out.println();
        System.out.println("-----------------------------Teacher-------------------------------");
        System.out.println();

        System.out.println("Getters:    ");
        System.out.println(teacher.toString());
        System.out.println();

        System.out.println("Setters:    ");

        teacher.setId(123);
        teacher.setEmail("sample.123@gmail.com");
        teacher.setPassword("invalid");
        teacher.setDegree("New Degree");
        teacher.setLevel("New level");
        teacher.setRole(UserRole.STUDENT);


        System.out.println(teacher.toString());
        System.out.println();
        System.out.println();
        System.out.println();


        System.out.println("-----------------------------Student-------------------------------");
        System.out.println();
        System.out.println(student.toString());
        System.out.println();
        System.out.println("Setters: ");
        student.setId(123);
        student.setEmail("eslibezsobachki");
        student.setPassword("NewPassword879?");
        student.setSubject("New subject");
        student.setGroupName("SE-2204");
        student.setRole(UserRole.TEACHER);
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println(student.toString());



    }
}