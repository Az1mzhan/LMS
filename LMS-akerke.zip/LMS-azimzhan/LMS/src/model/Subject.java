package model;

public class Subject {
    private String name;
    private String syllabus;
    private int creditNumber;

    public Subject(String name, String syllabus, int creditNumber) {
        this.name = name;
        this.syllabus = syllabus;
        this.creditNumber = creditNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSyllabus() {
        return syllabus;
    }

    public void setSyllabus(String syllabus) {
        this.syllabus = syllabus;
    }

    public int getCreditNumber() {
        return creditNumber;
    }

    public void setCreditNumber(int creditNumber) {
        this.creditNumber = creditNumber;
    }
}
