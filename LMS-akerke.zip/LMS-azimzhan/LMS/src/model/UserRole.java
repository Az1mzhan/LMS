package model;

public enum UserRole {
    TEACHER,
    STUDENT,
    ADMIN
}
